<template>
  <div>
    <h2 class="pointer" @click="refresh()">Metrics</h2>
  </div>
</template>

<script>
  import api from '../mixins/api'

  export default {
    name: 'Metrics',
    mixins: [api],
    data () {
      return {
        health: {},
        errors: []
      }
    },
    created () {
      this.refresh()
    },
    methods: {
      refresh () {
        this.$metrics().then(response => {
          this.$log.debug('>>> response=', response)
          this.health = response.data
        }).catch(e => {
          this.$log.error('Error while getting metrics: ', e)
          this.errors.push(e)
        })
      }
    }
  }
</script>
