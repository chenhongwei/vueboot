<template>
  <div>
    <h2 class="pointer" @click="refresh()">Health</h2>
    <mdc-button ><mdc-icon icon="favorite"></mdc-icon>like</mdc-button>
    <mdc-button @click="refresh()" :raised="true" :disabled="false">Refresh</mdc-button>
    <p>Global: <code>{{health.status}}</code></p>
    <p v-if="key !== 'status'" v-for="(value,key) of health">{{key}}: <code>{{value.status}}</code></p>
    <p class="alert alert-success">Health success</p>
    <p class="alert alert-danger">Health danger</p>
    <mdc-linear-progress accent progress=0.5></mdc-linear-progress>
  </div>
</template>

<script>
  import api from '../mixins/api'

  export default {
    name: 'Health',
    mixins: [api],
    data () {
      return {
        health: {},
        errors: []
      }
    },
    created () {
      this.refresh()
    },
    methods: {
      refresh () {
        this.$health().then(response => {
          this.$log.debug('>>> response=', response)
          this.health = response.data
        }).catch(e => {
          this.$log.error('Error while getting health: ', e)
          this.errors.push(e)
        })
      }
    }
  }
</script>
