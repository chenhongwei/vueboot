<template>
  <div id="app">
    <mdc-layout-app>

      <mdc-toolbar slot="toolbar" waterfall>
        <mdc-toolbar-row>
          <mdc-toolbar-section align-start>
            <mdc-toolbar-icon @click="$router.push('/')" icon="home"></mdc-toolbar-icon>
            <mdc-menu-anchor>
              <mdc-toolbar-icon @click="showSettings" icon="settings"></mdc-toolbar-icon>
              <mdc-menu ref="settingsMenu">
                <mdc-menu-item v-for="a of admin" :key="a" v-on:click.native="$router.push({name:a})" :disabled="$router.currentRoute.name === a">{{a}}</mdc-menu-item>
              </mdc-menu>
            </mdc-menu-anchor>
          </mdc-toolbar-section>
          <mdc-toolbar-section align-end>
            <mdc-menu-anchor>
              <mdc-toolbar-icon @click="showLanguages" icon="flag"></mdc-toolbar-icon>
              <mdc-menu ref="langMenu">
                <mdc-menu-item disabled>{{languages[current()]}}</mdc-menu-item>
                <mdc-menu-divider></mdc-menu-divider>
                <mdc-menu-item v-for="(display,key) of languages" :key="key" v-on:click.native="setLang(key)" v-if="current() !== key">{{display}}</mdc-menu-item>
              </mdc-menu>
            </mdc-menu-anchor>
            <mdc-toolbar-menu-icon></mdc-toolbar-menu-icon>
          </mdc-toolbar-section>
        </mdc-toolbar-row>
      </mdc-toolbar>

      <mdc-drawer slot="drawer" v-if="false">
      </mdc-drawer>

      <main id="main">
        <router-view v-cloak v-if="ready"/>
      </main>

    </mdc-layout-app>
  </div>
</template>

<script>
import nprogress from 'nprogress'
import axios from 'axios'
import Vue from 'vue'
import Logger from './mixins/logger'
import Vuex from 'vuex'
import vuexI18n from 'vuex-i18n'
import i18n from './mixins/i18n'

import MdcLayoutApp from 'vue-mdc-adapter/components/layout-app'
import MdcDrawer from 'vue-mdc-adapter/components/drawer'
import MdcToolbar from 'vue-mdc-adapter/components/toolbar'
import MdcButton from 'vue-mdc-adapter/components/button'
import MdcIcon from 'vue-mdc-adapter/components/icon'
import MdcProgress from 'vue-mdc-adapter/components/linear-progress'
import MdcMenu from 'vue-mdc-adapter/components/menu'
import MdcList from 'vue-mdc-adapter/components/list'

Vue.use(Logger)
Vue.use(Vuex)

Vue.use(MdcLayoutApp)
Vue.use(MdcDrawer)
Vue.use(MdcToolbar)
Vue.use(MdcButton)
Vue.use(MdcIcon)
Vue.use(MdcProgress)
Vue.use(MdcMenu)
Vue.use(MdcList)

const store = new Vuex.Store()
Vue.use(vuexI18n.plugin, store, {
  onTranslationNotFound (locale, key) {
    Vue.$log.warn(`i18n :: Key '${key}' not found for locale '${locale}'`)
  }
})

const calculatePercentage = (loaded, total) => (Math.floor(loaded * 1.0) / total)
let requestsCounter = 0

const setupStartProgress = () => {
  axios.interceptors.request.use(config => {
    requestsCounter++
    nprogress.start()
    return config
  })
}

const setupUpdateProgress = () => {
  const update = e => nprogress.inc(calculatePercentage(e.loaded, e.total))
  axios.defaults.onDownloadProgress = update
  axios.defaults.onUploadProgress = update
}

const setupStopProgress = () => {
  const responseFunc = response => {
    if ((--requestsCounter) === 0) {
      nprogress.done()
    }
    return response
  }

  const errorFunc = error => {
    if ((--requestsCounter) === 0) {
      nprogress.done()
    }
    return Promise.reject(error)
  }

  axios.interceptors.response.use(responseFunc, errorFunc)
}

nprogress.configure({ showSpinner: false })
setupStartProgress()
setupUpdateProgress()
setupStopProgress()

export default {
  name: 'app',
  mixins: [i18n],
  data () {
    return {
      ready: false,
      languages: {'fr': 'Français', 'en': 'English'},
      admin: ['Health', 'Metrics']
    }
  },
  created () {
    this.$log.debug('Env:', process.env)
    this.$changeLanguage('fr').then(() => { this.ready = true })
  },
  methods: {
    showLanguages () {
      this.$refs.langMenu.show()
    },
    showSettings () {
      this.$refs.settingsMenu.show()
    },
    setLang (language) {
      this.$changeLanguage(language)
    },
    current () {
      return Vue.i18n.locale()
    }
  }
}
</script>

<style lang="scss">
@import "../scss/_colors";
@import "../scss/_styles";

// @import "../scss/_material-icon";
$material-design-icons-font-path: "~material-design-icons-iconfont/dist/fonts/";
@import "~material-design-icons-iconfont/dist/material-design-icons.scss";

@import "~vue-mdc-adapter/components/button/styles";
@import "~vue-mdc-adapter/components/linear-progress/styles";
@import "~vue-mdc-adapter/components/layout-app/styles";
@import "~vue-mdc-adapter/components/drawer/styles";
@import "~vue-mdc-adapter/components/toolbar/styles";
@import "~vue-mdc-adapter/components/menu/styles";
@import "~vue-mdc-adapter/components/list/styles";

// @import "~bootstrap/scss/bootstrap";

@import "~bootstrap/scss/_functions";
@import "~bootstrap/scss/_variables";
@import "~bootstrap/scss/mixins/_border-radius";
@import "~bootstrap/scss/mixins/_box-shadow";
@import "~bootstrap/scss/mixins/_hover";
@import "~bootstrap/scss/mixins/_gradients";
@import "~bootstrap/scss/mixins/_breakpoints";

//@import "~bootstrap/scss/utilities/_display";
//@import "~bootstrap/scss/utilities/_flex";
//@import "~bootstrap/scss/utilities/_spacing";

@import "~bootstrap/scss/_root";
@import "~bootstrap/scss/_code";
@import "~bootstrap/scss/mixins/_badge";
@import "~bootstrap/scss/_badge";
@import "~bootstrap/scss/mixins/_alert";
@import "~bootstrap/scss/_alert";
</style>

<style>
[v-cloak] {
  display: none;
}
body {
  margin: unset;
}
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
}
#main {
  padding: 15px;
}
</style>
