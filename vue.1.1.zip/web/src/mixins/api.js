import axios from 'axios'

const baseUrl = process.env.BASE_URL

export default {
  methods: {
    $health () { return axios.get(`${baseUrl}health`) },
    $metrics () { return axios.get(`${baseUrl}metrics`) }
  }
}
