import Vue from 'vue'
import axios from 'axios'

export default {
  methods: {
    $changeLanguage (language) {
      if (Vue.i18n.locale() !== language) {
        if (!Vue.i18n.localeExists(language)) {
          return axios.get(`static/i18n/${language}.json`).then(response => {
            Vue.i18n.add(language, response.data)
            Vue.i18n.set(language)
          }).catch(e => {
            Vue.$log.error('Error while getting translation: ' + language, e)
            throw e
          })
        } else {
          Vue.i18n.set(language)
        }
      }
      return Promise.resolve()
    }
  }
}
