import Vue from 'vue'
import Router from 'vue-router'
import Home from '@/components/Home'
import Health from '@/components/Health'
import Metrics from '@/components/Metrics'

Vue.use(Router)

export default new Router({
  routes: [
    { path: '/', name: 'Home', component: Home },
    { path: '/health', name: 'Health', component: Health },
    { path: '/metrics', name: 'Metrics', component: Metrics }
  ]
})
