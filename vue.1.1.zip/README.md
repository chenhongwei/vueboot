# Vue

> A Vue.js project

## Plugins

https://github.com/dkfbasel/vuex-i18n
https://github.com/stasson/vue-mdc-adapter
https://github.com/rstacruz/nprogress/
https://github.com/axios/axios
https://github.com/justinkames/vuejs-logger

